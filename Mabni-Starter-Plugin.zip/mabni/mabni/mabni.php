<?php
/**
 * Plugin Name: Mabni – Page Builder
 * Description: A powerful visual page builder plugin for WordPress.
 * Version: 0.1
 * Author: Ahmad
 */

defined('ABSPATH') || exit;

function mabni_register_blocks() {
    register_block_type(__DIR__ . '/blocks/hero');
}
add_action('init', 'mabni_register_blocks');
